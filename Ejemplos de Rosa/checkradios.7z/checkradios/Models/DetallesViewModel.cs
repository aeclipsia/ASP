﻿namespace checkradios.Models
{
    public class DetallesViewModel
    {
        public String? sexo {  get; set; }

        public String[]? aficiones { get; set; }

        public String? curso {  get; set; }
    }
}
